#include "stm32f4xx_hal.h"
#include "stm32f4xx.h"
#include "LCD16x2Lib/LCD.h"

void initInterrupt(void);
void initIO(void);

void SysTick_Handler(void);

int main(void)
{
	SystemCoreClockUpdate();
	HAL_Init();
	
	initIO();
	initInterrupt();
	
	LCD_Init();
	LCD_Puts(3, 0, "Hello!");
	LCD_Puts(3, 1, "Hora!");	
	LCD_Delay_ms(5000);
	
	while (1)
	{
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
		HAL_Delay(1);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
		HAL_Delay(1);
	}
}

void initIO() {
		__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	
	GPIO_InitTypeDef PinConfig;
	PinConfig.Pin = GPIO_PIN_5 | GPIO_PIN_6;
	PinConfig.Mode = GPIO_MODE_OUTPUT_PP;
	PinConfig.Pull = GPIO_NOPULL;
	PinConfig.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(GPIOA, &PinConfig);
}

void initInterrupt()
{
	/*get external interrupt on PB0 (EXTI0)*/
	/*EXTI0_IRQHandler is called on every rising edge of PB0 */
	
	RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;
	EXTI->IMR |= EXTI_IMR_MR0_Msk;
	EXTI->RTSR |= EXTI_RTSR_TR0_Msk;
	SYSCFG->EXTICR[0] |= SYSCFG_EXTICR1_EXTI0_PB;
	__enable_irq();
	NVIC_SetPriority(EXTI0_IRQn, 0);
	NVIC_ClearPendingIRQ(EXTI0_IRQn);
	NVIC_EnableIRQ(EXTI0_IRQn);
}


void EXTI0_IRQHandler()
{
	EXTI->PR = EXTI_PR_PR0_Msk;
	NVIC_ClearPendingIRQ(EXTI0_IRQn);
	
	/* toggle PA6 on every rising edge of PB0 to get a 0.5 frequency */
	HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_6);
}

void SysTick_Handler()
{
  HAL_IncTick();
}
