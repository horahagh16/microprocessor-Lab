#include "stm32f4xx_hal.h"
#include "stm32f4xx.h"
#include "LCD16x2Lib/LCD.h"

void SysTick_Handler();
void EXTI15_10_IRQHandler()
{
	EXTI->PR |= (1 << 13);	// IMPORTANT!
	NVIC_ClearPendingIRQ(EXTI15_10_IRQn); // not necessary in case of using debouncing circuitry
}
int main(void)
{
	int counter = 0;
	int seconds = 0;
	SystemCoreClockUpdate();
	HAL_Init();
	
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	
	GPIO_InitTypeDef PinConfig;
	PinConfig.Pin = GPIO_PIN_5;
	PinConfig.Mode = GPIO_MODE_OUTPUT_PP;
	PinConfig.Pull = GPIO_NOPULL;
	PinConfig.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(GPIOA, &PinConfig);
	
	LCD_Init();
	LCD_Puts(3, 0, "Hello!");
	LCD_Puts(3, 1, "Hora!");	
	LCD_Delay_ms(5000);
	
	while (1)
	{
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
		HAL_Delay(1);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
		HAL_Delay(1);
		
		counter++;
		if (counter == 500)
		{
			LCD_Init();
			seconds++;
			int length = snprintf( NULL, 0, "%d", seconds );
			char* str = malloc( length + 1 );
			snprintf( str, length + 1, "%d", seconds );
			LCD_Puts(3, 0, str);
			counter = 0;
		}
	}
	return 0;
}

void SysTick_Handler()
{
  HAL_IncTick();
}
